import { d as defineEventHandler, g as getQuery, s as setHeader, c as createError } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const api_php_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const queryString = Object.keys(query).length > 0 ? "?" + new URLSearchParams(query).toString() : "";
  const targetUrl = `http://testtigshop.yufengzhe.cn/api.php${queryString}`;
  console.log("Proxying request to:", targetUrl);
  console.log("Query params:", query);
  try {
    const response = await fetch(targetUrl, {
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Referer": "http://testtigshop.yufengzhe.cn/"
      }
    });
    console.log("Response status:", response.status);
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Error response:", errorText);
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    const data = await response.text();
    console.log("Response received, length:", data.length);
    const contentType = response.headers.get("Content-Type") || "text/html; charset=utf-8";
    setHeader(event, "Content-Type", contentType);
    setHeader(event, "Access-Control-Allow-Origin", "*");
    return data;
  } catch (error) {
    console.error("Proxy error:", error);
    throw createError({
      statusCode: error.status || 500,
      statusMessage: `\u4EE3\u7406\u8BF7\u6C42\u5931\u8D25: ${error.message}`
    });
  }
});

export { api_php_get as default };
//# sourceMappingURL=api.php.get.mjs.map
